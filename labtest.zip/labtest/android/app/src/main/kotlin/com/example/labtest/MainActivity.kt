package com.example.labtest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
